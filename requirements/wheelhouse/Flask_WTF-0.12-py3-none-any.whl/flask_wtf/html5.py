# coding: utf-8
# flake8: noqa
from wtforms.widgets.html5 import *
from wtforms.fields.html5 import *
